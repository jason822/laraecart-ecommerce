<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Label language files for Ecommerce package
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default labels for ecommerce module,
    | and it is used by the template/view files in this module
    |
    */

    'name'          => 'Ecommerce',
    'names'         => 'Ecommerces',
];
