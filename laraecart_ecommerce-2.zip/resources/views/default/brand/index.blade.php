@extends('resource.index')
@php
$links['create'] = guard_url('ecommerce/brand/create');
$links['search'] = guard_url('ecommerce/brand');
@endphp

@section('icon') 
<i class="pe-7s-display2"></i>
@stop

@section('title') 
{!! __('ecommerce::brand.title.main') !!}
@stop

@section('sub.title') 
{!! __('ecommerce::brand.title.list') !!}
@stop

@section('breadcrumb') 
  <li><a href="{!!guard_url('/')!!}">{{ __('app.home') }}</a></li>
  <li><a href="{!!guard_url('ecommerce/brand')!!}">{!! __('ecommerce::brand.name') !!}</a></li>
  <li>{{ __('app.list') }}</li>
@stop

@section('entry') 
<div id="entry-form">

</div>
@stop

@section('list')
    @include('ecommerce::brand.partial.list.' . $view, ['mode' => 'list'])
@stop

@section('pagination') 
    {!!$brands->links()!!}
@stop

@section('script')

@stop

@section('style')

@stop 
