<?php

namespace Laraecart\Ecommerce\Interfaces;

interface CategoryRepositoryInterface
{
}
