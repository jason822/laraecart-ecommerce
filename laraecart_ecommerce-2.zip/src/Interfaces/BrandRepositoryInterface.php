<?php

namespace Laraecart\Ecommerce\Interfaces;

interface BrandRepositoryInterface
{
}
